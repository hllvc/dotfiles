#include <iostream>
#include "Person.h"
#include "Roster.h"
#include <string>
#include <vector>

using namespace std;

int main() {

	Roster roster;
	Person person("Adis", "H", "hllvc", "s", 5);
	roster.addPerson(person);

	roster.reportList();

}
