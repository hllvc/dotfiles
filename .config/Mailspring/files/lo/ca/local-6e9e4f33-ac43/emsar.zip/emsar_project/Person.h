#ifndef PERSON_H
#define PERSON_H

#include <iostream>
#include <string>

using namespace std;

class Person
{
   public:

        Person();
				Person(string, string, string, string, unsigned int);

        void setName(string), setLastName(string), setAge(int), setJMBG(unsigned int), setEmail(string), setDegree(string), setDepartment(string);

        string getName (), getLastName(), getEmail(), getDegree(), getDepartment(), details();
        int getAge();
				unsigned int getJMBG();

    private:

        string firstName, lastName, degree, email, department;
        int age;
				unsigned int jmbg;
};

#endif // PERSON_H
