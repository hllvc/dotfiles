#include <vector>
#include <iostream>

#include "Roster.h"

Roster::Roster(){
}

void Roster::addPerson(Person person){

	employees.push_back(person);

}

void Roster::reportList() {

	for(auto i = 0; i < employees.size(); i++)
		std::cout << employees.at(i).details();
}


