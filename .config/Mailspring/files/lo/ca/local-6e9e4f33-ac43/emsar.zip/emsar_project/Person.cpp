#include "Person.h"
#include <iostream>
#include <string>

using namespace std;

Person::Person(){
}

Person::Person(string firstName, string lastName, string email, string department, unsigned int jmbg) {

	this->firstName = firstName;
	this->lastName = lastName;
	this->email = email;
	this->department = department;
	this->jmbg = jmbg;
	this->degree = string('-', 5);
	this->age = 0;
}

void Person::setName (string firstName) {

        this->firstName = firstName;
}

string Person::getName (){
    return this->firstName;
}

void Person::setLastName(string lastName){

    this->lastName = lastName;
}

string Person::getLastName(){

    return this->lastName;

}

void Person::setJMBG (unsigned int jmbg){
    this->jmbg = jmbg;
}

unsigned int Person::getJMBG(){
    return this->jmbg;
}

void Person::setAge(int age){
    this->age = age;
}

int Person::getAge(){
    return this->age;
}

void Person::setEmail(string email){
    this->email = email;
}

string Person::getEmail(){
    return this->email;
}

void Person::setDegree(string degree) {
    this->degree = degree;
}

string Person::getDegree(){
    return this->degree;
}

void Person::setDepartment(string departemnt){
    this->department = departemnt;
}

string Person::getDepartment(){
    return department;
}

string Person::details() {

	return getName();
}
